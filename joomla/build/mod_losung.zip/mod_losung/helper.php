<?php
/**
 * @package     Joomla.Site
 * @subpackage  mod_losung
 *
 * @copyright   Copyright (C) 2025 Max Nötzold. All rights reserved.
 * @license     ISC
 */

defined('_JEXEC') or die;

/**
 * Helper class for Random CSV module
 */
class ModDailyBibleVerseHelper
{
    /**
     * Gets today's Losung entry from the appropriate CSV file
     *
     * @param string $csvFolderPath Path to the CSV files directory
     * @return array|null Array containing today's Losung data or null if not found
     */
    public static function getTodaysLosung($csvFolderPath)
    {
        // Get current date information
        $date = new JDate();
        $currentYear = $date->format('Y');
        $todayString = $date->format('d.m.Y');
        
        // Determine the full path to the CSV file for the current year
        $csvFileName = 'Losungen' . $currentYear . '.csv';
        $fullPath = JPATH_ROOT . '/' . $csvFolderPath . '/' . $csvFileName;
        
        // Initialize return variable
        $todaysEntry = null;
        
        // Check if file exists and is readable
        if (file_exists($fullPath) && is_readable($fullPath)) {
            if (($handle = fopen($fullPath, "r")) !== false) {
                // Read all lines from the CSV file - using tab as delimiter
                while (($data = fgetcsv($handle, 1000, "\t")) !== false) {
                    // Check if this row matches today's date (in first column)
                    if (isset($data[0]) && $data[0] === $todayString) {
                        $todaysEntry = $data;
                        break;
                    }
                }
                
                fclose($handle);
            }
        } else {
            // Log error if file doesn't exist or isn't readable
            JFactory::getApplication()->enqueueMessage(
                JText::sprintf('MOD_LOSUNG_FILE_ERROR_SPECIFIC', $csvFileName),
                'warning'
            );
        }
        
        return $todaysEntry;
    }
}